<div class="container_item_accessories">
	@foreach($accessory_items as $item)
	@include('accessories.partials.item_div')
	@include('accessories.partials.item_div')
	@include('accessories.partials.item_div')
	@include('accessories.partials.item_div')

	@include('accessories.partials.item_div')
	@include('accessories.partials.item_div')
	@include('accessories.partials.item_div')
	@include('accessories.partials.item_div')

	@include('accessories.partials.item_div')
	@include('accessories.partials.item_div')
	@include('accessories.partials.item_div')

	@include('accessories.partials.item_div')
	@include('accessories.partials.item_div')
	@include('accessories.partials.item_div')

	@include('accessories.partials.item_div')
	@include('accessories.partials.item_div')
	@include('accessories.partials.item_div')

	@include('accessories.partials.item_div')
	@include('accessories.partials.item_div')
	@include('accessories.partials.item_div')
	@include('accessories.partials.item_div')
	@include('accessories.partials.item_div')
	@include('accessories.partials.item_div')
	@include('accessories.partials.item_div')
	@include('accessories.partials.item_div')
	@include('accessories.partials.item_div')
	@include('accessories.partials.item_div')
	@include('accessories.partials.item_div')


	@include('accessories.partials.item_div')

	@include('accessories.partials.item_div')
	@include('accessories.partials.item_div')

	@include('accessories.partials.item_div')
	@include('accessories.partials.item_div')


	@include('accessories.partials.item_div')
	@include('accessories.partials.item_div')
    @endforeach
</div>