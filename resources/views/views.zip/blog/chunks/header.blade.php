 <header id="header">
     
      <div class="header_bottom">
        <div class="logo_area"><a class="logo" href="{{url('blog')}}"><b>Mobilein</b>Pakistan<span>Find Your Dream Mobile</span></a></div>
        <div class="top_addarea"><a href="#"><img src="{{ URL::asset('userblog/images/addbanner_728x90_V1.jpg') }}" alt=""></a></div>
      </div>
    </header>