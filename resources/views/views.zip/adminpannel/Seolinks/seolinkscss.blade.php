<style type="text/css">
.select2-container--default .select2-selection--single {


	display: block !important;
	width: 100% !important;
	height: 34px !important;
	padding: 6px 12px !important;
	font-size: 14px !important;
	line-height: 1.42857143 !important;
	color: #555 !important;
	background-color: #fff !important;
	background-image: none !important;
	border: 1px solid #ccc !important;
	border-radius: 4px !important;;

}

dt {
    font-weight: 700;
    color: tomato;
    font-size: medium;
    margin-bottom: 5px;
}
dd{
	   font-weight: 400;
    background: white;
    font-style: oblique;
    font-size: large;
       color: #47525d;

}
dd, dt {
    line-height: 30px !important;
}
.box {
    background: white !important;
}
.items{border: 1px solid darkgrey;
    padding: 15px;
}
.box-title{
	font-weight: 800;
    color: indianred;
    margin-left: 15px;
    padding: 12px;
    border: 1px solid darkgreen;
}
</style>