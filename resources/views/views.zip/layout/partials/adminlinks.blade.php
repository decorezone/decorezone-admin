  <div class="navbar navbar-fixed-top">
    <div class="subnavbar">
      <div class="subnavbar-inner">
        <div class="container">
          <ul class="mainnav">
            <li class="active"><a href="{{URL('AdminDashboard')}}"><i class=" icon-home"></i><span>Dashboard</span> </a> </li>
           <!--  <li><a href="{{ URL('AllMobilesByBrands') }}"><i class="icon-list"></i><span>Mobiles</span> </a> </li> -->
            <li><a href="{{ URL('admin/pages') }}"><i class="icon-file"></i><span>Pages</span> </a> </li><!-- 
            <li><a href="shortcodes.html"><i class="icon-shopping-cart"></i><span>Sales</span> </a> </li>
            <li><a href="shortcodes.html"><i class="icon-money"></i><span>Accounting</span> </a> </li>
            <li><a href="shortcodes.html"><i class="icon-signal"></i><span>Reports</span> </a> </li>
            <li><a href="charts.html"><i class="icon-user"></i><span>HR</span> </a> </li>
            <li><a href="charts.html"><i class="icon-bullhorn"></i><span>Notifications</span> </a> </li>
            <li><a href="charts.html"><i class="icon-cogs"></i><span>Business Settings</span> </a> </li> -->
           
          </ul>
        </div>
        <!-- /container --> 
      </div>
      <!-- /subnavbar-inner --> 
    </div>
  </div>

