
<script src="{{ URL::asset('admin/js/jquery-1.7.2.min.js') }}"></script> 
<script src="{{ URL::asset('admin/js/bootstrap.js') }}"></script>
<script src="{{ URL::asset('SelectTwo/select2.min.js') }}"></script>
</body>
</html>
