<!DOCTYPE html>
@include('user.chunks.head')
@yield('userdash')
@include('user.chunks.footer')
@yield('jsfiles')
</html>