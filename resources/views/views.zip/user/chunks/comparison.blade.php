 <img  src="{{ URL::asset('mobile_pics/'.$mob->pic_folder.'/'.$mob->main_pic) }}" alt="description here"  width="50" height="100" class="png" />
     
    