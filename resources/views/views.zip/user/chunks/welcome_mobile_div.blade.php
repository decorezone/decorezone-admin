	<div class="container_mob">
		@foreach($latest_mobile as $mob)
		<div class="mobitem">
			@include('user.chunks.mobile_table_div')
		</div>
		@endforeach
	</div>
	<p class="price_bar">Mobile Price More then 100,000
	</p>
	<span id="down-triangle"></span>
	

	 
	<div class="container_mob">
		@foreach($max_range as $mob)
		<div class="mobitem">
			@include('user.chunks.mobile_table_div')
		</div>
		@endforeach
	</div>
	<p class="price_bar">Mobile Price 80,000 to 99,000</p>
	<div class="container_mob">
		@foreach($range_two as $mob)
		<div class="mobitem">
			@include('user.chunks.mobile_table_div')
		</div>
		@endforeach
	</div>
	<p class="price_bar">Mobile Price 60,000 to 80,000</p>
	<div class="container_mob">
		@foreach($range_three as $mob)
		<div class="mobitem">
			@include('user.chunks.mobile_table_div')
		</div>
		@endforeach
	</div>
	<p class="price_bar">Mobile Price 50,000 to 60,000</p>
	<div class="container_mob">
		@foreach($range_four as $mob)
		<div class="mobitem">
			@include('user.chunks.mobile_table_div')
		</div>
		@endforeach
	</div>
	<p class="price_bar">Mobile Price 30,000 to 50,000</p>
	<div class="container_mob">
		@foreach($range_five as $mob)
		<div class="mobitem">
			@include('user.chunks.mobile_table_div')
		</div>
		@endforeach
	</div>
	<p class="price_bar">Mobile Price 25,000 to 30,000</p>
	<div class="container_mob">
		@foreach($range_six as $mob)
		<div class="mobitem">
			@include('user.chunks.mobile_table_div')
		</div>
		@endforeach
	</div>
	<p class="price_bar">Mobile Price 20,000 to 25,000</p>
	<div class="container_mob">
		@foreach($range_seven as $mob)
		<div class="mobitem">
			@include('user.chunks.mobile_table_div')
		</div>
		@endforeach
	</div>
	<p class="price_bar">Mobile Price less then 15,000


	</p>
	<div class="container_mob">
		@foreach($range_eight as $mob)
		<div class="mobitem">
			@include('user.chunks.mobile_table_div')
		</div>
		@endforeach
	</div>
	