
<div class="container_mob">

		@foreach($coming_soon as $mob)
		<div class="mobitem">
			@include('user.chunks.mobile_table_div')
		</div>
		@endforeach
</div>